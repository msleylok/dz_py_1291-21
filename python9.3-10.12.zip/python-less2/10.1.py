list_x = list(range(10,30,2))
for i in range(0, len(list_x)):
    y = list_x[i] * 2 + 3
    print(y)
