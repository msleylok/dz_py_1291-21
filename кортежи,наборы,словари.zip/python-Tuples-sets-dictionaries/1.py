names = ['Tom', 'Mark', 'Elsa', 'Andrew', 'Jill']
print(names)
names.sort()
print(names)
