friends_names = {'Michael', 'Mark', 'George', 'David', 'Donald', 'Brian', 'Thomas'}
pop_names = {'James', 'John', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Charles', 'Joseph', 'Thomas'}
print(friends_names & pop_names)
    
