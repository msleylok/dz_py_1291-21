info = {'Name': 'Salekh', 'Surname': 'Mamadaliev', 'age': 19}
print(info)
