phone = {}
phone['Модель'] = 'Samsung Galaxy A5'
phone['Диагональ экрана'] = '5.2 дюйма'
phone['Цвет'] = 'Черный'
phone['Камера'] = '16 MP'
phone['OS'] = 'Android 8.0'
phone['CPU'] = 'Cortex-A53 1.9 GHz'
phone['GPU'] = 'Mali-T830MP3'
phone['Объём памяти'] = '32 GB'
phone['ОЗУ'] = '3 GB'
print(phone)
